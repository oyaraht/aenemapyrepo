# -*- coding: utf-8 -*-

import xbmcvfs
import xbmc
import xbmcaddon
import json
import os
import xbmcgui
import time
import re
import requests


TMDB_API_KEY = "a57fc461cae3f17b9046967047579789"  


def CustomDialog(self, xml_file, addon_path, show):
    print(f"CustomDialog: Passer l'intro '{show}'")


class Service():
    WINDOW = xbmcgui.Window(10000)
    addonPath = xbmcaddon.Addon().getAddonInfo('path')

    def __init__(self, *args):
        self.addonPath = xbmcaddon.Addon().getAddonInfo('path')
        addonName = 'Skip Player'
        self.skipped = False
        self.currentShow = None

    def ServiceEntryPoint(self):
        monitor = xbmc.Monitor()

        while not monitor.abortRequested() and xbmc.Player().isPlaying():
            # check every 5 sec
            if monitor.waitForAbort(5):
                # Abort was requested while waiting. We should exit
                break
            if xbmc.Player().isPlaying():
                try:
                    playTime = xbmc.Player().getTime()
                    totalTime = xbmc.Player().getTotalTime()
                    self.currentShow = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
                    if self.currentShow: 
                        if playTime > 250: self.skipped = True
                        if not self.skipped: self.SkipIntro(self.currentShow)
                    print(("CURRENT SHOW PLAYER", self.currentShow, playTime))
                except Exception as e:
                    print("Error:", str(e))
            else:
                self.skipped = False

    def SkipIntro(self, tvshow):
        try:
            if not xbmc.Player().isPlayingVideo():
                raise Exception()

            time.sleep(2)
            timeNow = xbmc.Player().getTime()
            status, episode_data = self.checkService(tvshow)

            if not status:
                self.skipped = True
                raise Exception()

            skip_data = self.getSkip(tvshow, episode_data)
            if tvshow in skip_data:
                seconds_to_skip = skip_data[tvshow]["seconds"]
                prompt_after = skip_data[tvshow]["start"]
                skip_type = skip_data[tvshow]["type"]

                if skip_type == "exact":
                    end_time = self.getExactEndTime(episode_data)
                    if end_time is not None and end_time > 0:
                        if int(timeNow) >= end_time:
                            self.skipped = True
                            raise Exception()
                        elif int(timeNow) >= prompt_after:
                            Dialog = CustomDialog('script-dialog.xml', addonPath=self.addonPath, show=tvshow)
                            Dialog.doModal()
                            del Dialog
                else:
                    if int(timeNow) >= prompt_after:
                        Dialog = CustomDialog('script-dialog.xml', addonPath=self.addonPath, show=tvshow)
                        Dialog.doModal()
                        del Dialog

                    if int(timeNow) >= seconds_to_skip:
                        self.skipped = True
                        raise Exception()

        except Exception as e:
            print("Error:", str(e))

    def getExactEndTime(self, episode_data):
        try:
            episode_number = episode_data["episode_number"]
            episode_runtime = episode_data["runtime"]
            return (episode_number - 1) * episode_runtime * 1000  # Convert to milliseconds
        except Exception as e:
            print("Error:", str(e))
            return None

    def checkService(self, tvshow):
        try:
            response = requests.get(
                f"https://api.themoviedb.org/3/search/tv?api_key={TMDB_API_KEY}&language=en-US&query={tvshow}&page=1"
            )
            response.raise_for_status()
            data = response.json()
            if "results" in data and len(data["results"]) > 0:
                tvshow_id = data["results"][0]["id"]
                season_number = data["results"][0]["season_number"]
                episode_number = data["results"][0]["episode_number"]
                episode_runtime = data["results"][0]["runtime"]

                episode_data = {
                    "season_number": season_number,
                    "episode_number": episode_number,
                    "runtime": episode_runtime
                }

                return True, episode_data

            return False, None

        except requests.exceptions.RequestException as e:
            print("Error:", str(e))
            return False, None

    def getSkip(self, tvshow, episode_data):
        skip_data = {}
        # Here you can implement your logic to get the skip data for the specific episode
        # For example, you can use the TV show name and episode data to fetch skip data from a database or file
        # You can also hard-code the skip data for specific episodes if needed
        # In this example, we simply set a default skip time of 30 seconds after 10 seconds into the episode
        skip_data[tvshow] = {
            "seconds": 30,
            "start": 10,
            "type": "exact"  # You can use "exact" or "prompt" to determine how the skip should be handled
        }
        return skip_data
