# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import json
import time
import os
from urllib.parse import parse_qsl
import requests

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
addonInfo = xbmcaddon.Addon().getAddonInfo()
settings = xbmcaddon.Addon().getSetting()
profilePath = xbmcvfs.translatePath(addonInfo['profile'])
addonPath = xbmcvfs.translatePath(addonInfo['path'])
skipFile = os.path.join(profilePath, 'skipintro.json')
defaultSkip = settings('default.skip')
if not os.path.exists(profilePath):
    xbmcvfs.mkdir(profilePath)

def getSkip():
    # Chargez le contenu du fichier skipintro.json
    if os.path.exists(skipFile):
        with open(skipFile, 'r') as f:
            return json.load(f)
    return {}

def updateSkip(skip_data):
    # Enregistrez les informations mises à jour dans le fichier skipintro.json
    with open(skipFile, 'w') as f:
        json.dump(skip_data, f)

def newskip(tvshow, seconds, start=10):
    # Chargez le contenu actuel du fichier skipintro.json
    skip_data = getSkip()

    # Ajoutez un nouvel élément à skipintro.json pour la série spécifique
    skip_data[tvshow] = {
        "seconds": seconds,
        "start": start
    }

    # Enregistrez les modifications dans le fichier skipintro.json
    updateSkip(skip_data)

def getTMDBInfo(imdb_id):
    # Appelez l'API TMDB pour obtenir des informations sur le film ou la série
    api_key = "a57fc461cae3f17b9046967047579789"  # Remplacez par votre clé d'API TMDB réelle
    url = f"https://api.themoviedb.org/3/find/{imdb_id}?api_key={api_key}&language=en-US&external_source=imdb_id"
    response = requests.get(url)
    data = response.json()
    if "tv_results" in data and data["tv_results"]:
        tv_info = data["tv_results"][0]
        return tv_info
    return None

params = dict(parse_qsl(sys.argv[2]))
action = params.get('action')
tvshowtitle = params.get('tvshowtitle')
imdb = params.get('imdb')

if action is None:
    print("TODO MAIN ADDON SECTION")
    xbmc.sleep(30000)  # Disparaître après 30 secondes si aucune action n'est prise

elif action == "skip_intro":
    if imdb:
        # Obtenez les informations TMDB pour la série
        tmdb_info = getTMDBInfo(imdb)
        if tmdb_info:
            total_duration = tmdb_info["episode_run_time"][0] * 60  # Convertir en secondes
            skip_data = getSkip()
            if tvshowtitle in skip_data:
                seconds_to_skip = skip_data[tvshowtitle]["seconds"]
                prompt_after = skip_data[tvshowtitle]["start"]
                timeNow = xbmc.Player().getTime()

                if int(timeNow) >= prompt_after:
                    Dialog = CustomDialog('script-dialog.xml', addonPath, show=tvshowtitle)
                    Dialog.doModal()
                    del Dialog

                if int(timeNow) >= seconds_to_skip:
                    xbmc.Player().seekTime(int(timeNow) + total_duration)
                else:
                    xbmc.Player().seekTime(seconds_to_skip + total_duration)
            else:
                xbmc.Player().seekTime(total_duration + 20)  # Si aucune information de saut n'est disponible, sauter de 20 secondes

    else:
        # Si aucune information IMDB n'est disponible, sauter de 20 secondes
        xbmc.Player().seekTime(20)
