# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import json
import time
import os
import sqlite3
import sys
from urllib.parse import parse_qsl

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0])
addon = xbmcaddon.Addon()
addonInfo = xbmcaddon.Addon().getAddonInfo()
profilePath = xbmcvfs.translatePath(addonInfo['profile'])
addonPath = xbmcvfs.translatePath(addonInfo['path'])
skipFile = os.path.join(profilePath, 'skipintro.json')
defaultSkip = addon.getSettingInt('default.skip')
if not os.path.exists(profilePath):
    xbmcvfs.mkdir(profilePath)

def get_tvshows():
    db_file = xbmcvfs.translatePath("special://database/MyVideos119.db")
    connection = sqlite3.connect(db_file)
    cursor = connection.cursor()
    query = "SELECT c00 FROM tvshow"
    cursor.execute(query)
    tvshows = cursor.fetchall()
    cursor.close()
    connection.close()
    tvshow_list = [tvshow[0] for tvshow in tvshows]
    return tvshow_list

def onPlayBackStarted():
    tvshowtitle = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
    if tvshowtitle:
        SkipIntro(tvshowtitle)

def getSkip():
    if os.path.exists(skipFile):
        with open(skipFile, 'r') as f:
            return json.load(f)
    return {}

def updateSkip(skip_data):
    with open(skipFile, 'w') as f:
        json.dump(skip_data, f)

def newskip(tvshow_list, seconds=20, start=10):
    skip_data = getSkip()
    for tvshow in tvshow_list:
        skip_data[tvshow] = {
            "seconds": seconds,
            "start": start
        }
    updateSkip(skip_data)

def SkipIntro(tvshowtitle):
    skip_data = getSkip()
    if tvshowtitle in skip_data:
        intro_duration = skip_data[tvshowtitle]["start"]
        time.sleep(intro_duration) 

        dialog = xbmcgui.Dialog()
        language = xbmc.getLanguage(xbmc.ISO_639_1)
        message = "Skip Intro" if language == "en" else "Passez l'Intro"
        button = dialog.yesno("Passer l'intro", message, nolabel="Non", yeslabel="Oui", autoclose=20000)

        if button:
            total_duration = skip_data[tvshowtitle]["seconds"]
            xbmc.Player().seekTime(int(total_duration))

def addDefaultSkip():
    skip_data = getSkip()
    skip_data["Série TV"] = {
        "Numéro de saison": "all",
        "Numéro d'épisode": "all",
        "Durée de l'introduction de l'épisode (en secondes)": defaultSkip
    }
    updateSkip(skip_data)

def create_skip_file():
    series_list = get_tvshows()
    skip_data = {}
    for tvshow in series_list:
        episodes = []
        db_file = xbmcvfs.translatePath("special://database/MyVideos119.db")
        connection = sqlite3.connect(db_file)
        cursor = connection.cursor()
        query = f"SELECT c12, c13 FROM episode WHERE idShow IN (SELECT idShow FROM tvshow WHERE c00='{tvshow}')"
        cursor.execute(query)
        tv_episodes = cursor.fetchall()
        cursor.close()
        connection.close()
        for episode in tv_episodes:
            episode_title = episode[0]
            episode_duration = int(episode[1])
            episodes.append({
                "title": episode_title,
                "duration": episode_duration
            })

        skip_data[tvshow] = {
            "seconds": 20,
            "start": 10,
            "episodes": episodes
        }

    updateSkip(skip_data)

def manual_scan():
    create_skip_file()
    newskip(get_tvshows(), seconds=20)
    addDefaultSkip()
    xbmcgui.Dialog().notification("Scan terminé", "Le fichier skipintro.json a été mis à jour.", xbmcgui.NOTIFICATION_INFO)

def scheduled_scan():
    create_skip_file()
    newskip(get_tvshows(), seconds=20)
    addDefaultSkip()

def schedule_recurring_scan(interval_days):
    # Calculate the next scan time
    next_scan_time = time.time() + interval_days * 24 * 60 * 60
    while True:
        current_time = time.time()
        remaining_time = next_scan_time - current_time
        if remaining_time <= 0:
            scheduled_scan()
            next_scan_time = current_time + interval_days * 24 * 60 * 60
        xbmc.sleep(int(remaining_time * 1000))

def create_import_file():
    series_list = get_tvshows()
    import_data = {}
    for tvshow in series_list:
        episodes = []
        db_file = xbmcvfs.translatePath("special://database/MyVideos119.db")
        connection = sqlite3.connect(db_file)
        cursor = connection.cursor()
        query = f"SELECT c12, c13, c14, c15 FROM episode WHERE idShow IN (SELECT idShow FROM tvshow WHERE c00='{tvshow}')"
        cursor.execute(query)
        tv_episodes = cursor.fetchall()
        cursor.close()
        connection.close()
        for episode in tv_episodes:
            episode_title = episode[0]
            season_number = int(episode[1])
            episode_number = int(episode[2])
            episode_duration = int(episode[3])
            episodes.append({
                "title": episode_title,
                "season": season_number,
                "episode": episode_number,
                "duration": episode_duration
            })

        import_data[tvshow] = episodes

    with open("import.json", "w") as f:
        json.dump(import_data, f)

def onAddonInstall():

    create_import_file()

    create_skip_file()
    newskip(get_tvshows(), seconds=20)
    addDefaultSkip()

xbmcaddon.Addon().setSetting("installcomplete", "true")
onAddonInstall()

xbmc.Player().onPlayBackStarted(onPlayBackStarted)

def show_skip_dialog():
    dialog = xbmcgui.Dialog()
    language = xbmc.getLanguage(xbmc.ISO_639_1)
    message = "Skip Intro" if language == "en" else "Passez l'Intro"
    button = dialog.yesno("Passer l'intro", message, nolabel="Non", yeslabel="Oui", autoclose=20000)

    if button:
        total_duration = 20
        xbmc.Player().seekTime(int(total_duration))

def show_settings():
    """
    Affiche la fenêtre de paramètres personnalisée.
    """
    addon = xbmcaddon.Addon()
    dialog = xbmcgui.Dialog()

    # Crée une liste des paramètres pour la fenêtre de paramètres
    setting_list = [
        {
            "type": "bool",
            "label": "Afficher sur la timeline",
            "id": "ShowOnTimeline",
            "default": False
        },
        {
            "type": "path",
            "label": "Image de fond",
            "id": "BackgroundImage",
            "default": "special://home/addons/script.tvskipintro/resources/skin/NetflixStyle/background.jpg"
        },
        {
            "type": "path",
            "label": "Image du bouton",
            "id": "ButtonImage",
            "default": "special://home/addons/script.tvskipintro/resources/skin/NetflixStyle/skip_button.png"
        },
        # Ajoutez ici d'autres paramètres personnalisés
    ]

    # Affiche la fenêtre de paramètres
    if dialog.settings(addon.getAddonInfo('id'), title=addon.getAddonInfo('name'), window=setting_list):
        # Si l'utilisateur a cliqué sur "OK", enregistre les paramètres
        for setting in setting_list:
            addon.setSetting(setting['id'], dialog.getSetting(setting['id']))

def get_settings():
    """
    Récupère les valeurs des paramètres choisis par l'utilisateur.
    """
    addon = xbmcaddon.Addon()
    show_on_timeline = addon.getSettingBool("ShowOnTimeline")
    background_image = addon.getSetting("BackgroundImage")
    button_image = addon.getSetting("ButtonImage")
    # Ajoutez ici la récupération d'autres paramètres personnalisés si nécessaire

    return show_on_timeline, background_image, button_image

def handle_params():
    params = dict(parse_qsl(sys.argv[2]))
    action = params.get('action')
    if action is None:
        show_settings()
        xbmc.sleep(30000)
    elif action == "skip_intro":
        SkipIntro(params.get('tvshowtitle'))
    elif action == "settings":
        show_settings()

handle_params()
