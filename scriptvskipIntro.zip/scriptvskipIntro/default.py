# -*- coding: utf-8 -*-

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs
import json
import os
import sqlite3
import time
from urllib.parse import parse_qsl

def load_custom_css():
    css_file = xbmcvfs.translatePath("special://home/addons/script.tvskipintro/resources/skin/NetflixStyle/style.css")
    xbmc.executebuiltin(f"LoadProfile({css_file})")

addon = xbmcaddon.Addon()
addonInfo = addon.getAddonInfo()
profilePath = xbmcvfs.translatePath(addonInfo['profile'])
addonPath = xbmcvfs.translatePath(addonInfo['path'])
skipFile = os.path.join(profilePath, 'skipintro.json')
defaultSkip = addon.getSettingInt('default.skip')

if not os.path.exists(profilePath):
    xbmcvfs.mkdir(profilePath)

def get_tvshows():
    db_file = xbmcvfs.translatePath("special://database/MyVideos119.db")
    connection = sqlite3.connect(db_file)
    cursor = connection.cursor()
    query = "SELECT c00 FROM tvshow"
    cursor.execute(query)
    tvshows = cursor.fetchall()
    cursor.close()
    connection.close()
    tvshow_list = [tvshow[0] for tvshow in tvshows]
    return tvshow_list

def getSkip():
    if os.path.exists(skipFile):
        with open(skipFile, 'r') as f:
            return json.load(f)
    return {}

def updateSkip(skip_data):
    with open(skipFile, 'w') as f:
        json.dump(skip_data, f)

def create_skip_data():
    series_list = get_tvshows()
    skip_data = {}
    for tvshow in series_list:
        episodes = []
        db_file = xbmcvfs.translatePath("special://database/MyVideos119.db")
        connection = sqlite3.connect(db_file)
        cursor = connection.cursor()
        query = f"SELECT c12, c13 FROM episode WHERE idShow IN (SELECT idShow FROM tvshow WHERE c00='{tvshow}')"
        cursor.execute(query)
        tv_episodes = cursor.fetchall()
        cursor.close()
        connection.close()
        for episode in tv_episodes:
            episode_title = episode[0]
            episode_duration = int(episode[1])
            episodes.append({
                "title": episode_title,
                "duration": episode_duration
            })

        skip_data[tvshow] = {
            "seconds": 20,
            "start": 10,
            "episodes": episodes
        }

    updateSkip(skip_data)

def addDefaultSkip():
    skip_data = getSkip()
    skip_data["Série TV"] = {
        "Numéro de saison": "all",
        "Numéro d'épisode": "all",
        "Durée de l'introduction de l'épisode (en secondes)": defaultSkip
    }
    updateSkip(skip_data)

def onPlayBackStarted():
    tvshowtitle = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
    if tvshowtitle:
        SkipIntro(tvshowtitle)

def SkipIntro(tvshowtitle):
    skip_data = getSkip()
    if tvshowtitle in skip_data:
        intro_duration = skip_data[tvshowtitle]["start"]
        time.sleep(intro_duration)

        dialog = xbmcgui.Dialog()
        language = xbmc.getLanguage(xbmc.ISO_639_1)
        message = "Skip Intro" if language == "en" else "Passez l'Intro"
        button = dialog.yesno("Passer l'intro", message, nolabel="Non", yeslabel="Oui", autoclose=30000)

        if button:
            total_duration = skip_data[tvshowtitle]["seconds"]
            xbmc.Player().seekTime(int(total_duration))

def handle_default_actions():
    # TODO: Ajoutez ici la logique pour gérer les actions par défaut de l'addon.
    # Dans cet exemple, nous affichons simplement la boîte de dialogue pour passer l'intro lorsque l'épisode démarre.
    dialog = xbmcgui.Dialog()
    language = xbmc.getLanguage(xbmc.ISO_639_1)
    message = "Skip Intro" if language == "en" else "Passez l'Intro"
    button = dialog.yesno("Passer l'intro", message, nolabel="Non", yeslabel="Oui", autoclose=30000)

    if button:
        total_duration = 20
        xbmc.Player().seekTime(int(total_duration))

def run_default_actions():
    # TODO: Ajoutez ici la logique pour déclencher les actions par défaut de l'addon.
    # Dans cet exemple, nous appelons simplement la fonction `handle_default_actions`.
    handle_default_actions()

def onAddonInstall():
    create_skip_data()
    addDefaultSkip()

if __name__ == "__main__":
    xbmcaddon.Addon().setSetting("installcomplete", "true")
    onAddonInstall()
    xbmc.Player().onPlayBackStarted(onPlayBackStarted)
    run_default_actions()
