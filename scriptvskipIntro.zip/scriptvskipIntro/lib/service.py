# -*- coding: utf-8 -*-

import xbmcvfs
import xbmc
import xbmcaddon
import json
import os
import xbmcgui
import time
import sqlite3

class Service():
    WINDOW = xbmcgui.Window(10000)

    def __init__(self, *args):
        self.addonPath = xbmcaddon.Addon().getAddonInfo('path')
        addonName = 'Skip Player'
        self.skipped = False
        self.currentShow = None
        self.skipData = self.loadSkipData()

    def ServiceEntryPoint(self):
        monitor = xbmc.Monitor()

        while not monitor.abortRequested() and xbmc.Player().isPlaying():
            # check every 5 sec
            if monitor.waitForAbort(5):
                # Abort was requested while waiting. We should exit
                break
            if xbmc.Player().isPlaying():
                try:
                    playTime = xbmc.Player().getTime()
                    totalTime = xbmc.Player().getTotalTime()
                    self.currentShow = xbmc.getInfoLabel("VideoPlayer.TVShowTitle")
                    if self.currentShow:
                        if playTime > 250:
                            self.skipped = True
                        if not self.skipped:
                            self.SkipIntro(self.currentShow)
                    print(("CURRENT SHOW PLAYER", self.currentShow, playTime))
                except Exception as e:
                    print("Error:", str(e))
            else:
                self.skipped = False

    def SkipIntro(self, tvshow):
        try:
            if not xbmc.Player().isPlayingVideo():
                raise Exception()

            time.sleep(2)
            timeNow = xbmc.Player().getTime()
            status, episode_data = self.checkService(tvshow)

            if not status:
                self.skipped = True
                raise Exception()

            if tvshow in self.skipData:
                skip_info = self.skipData[tvshow]
                seconds_to_skip = skip_info["seconds"]
                prompt_after = skip_info["start"]
                skip_type = skip_info["type"]

                if skip_type == "exact":
                    end_time = self.getExactEndTime(episode_data)
                    if end_time is not None and end_time > 0:
                        if int(timeNow) >= end_time:
                            self.skipped = True
                            raise Exception()
                        elif int(timeNow) >= prompt_after:
                            self.showSkipDialog(tvshow)
                else:
                    if int(timeNow) >= prompt_after:
                        self.showSkipDialog(tvshow)

                    if int(timeNow) >= seconds_to_skip:
                        self.skipped = True
                        raise Exception()

        except Exception as e:
            print("Error:", str(e))

    def showSkipDialog(self, tvshow):
        Dialog = xbmcgui.Dialog()
        language = xbmc.getLanguage(xbmc.ISO_639_1)
        message = "Skip Intro" if language == "en" else "Passez l'Intro"
        button = Dialog.yesno("Passer l'intro", message, nolabel="Non", yeslabel="Oui", autoclose=30000)
        del Dialog

        if button:
            total_duration = self.skipData[tvshow]["seconds"]
            xbmc.Player().seekTime(int(total_duration))

    def getExactEndTime(self, episode_data):
        try:
            episode_number = episode_data["episode_number"]
            episode_runtime = episode_data["runtime"]
            return (episode_number - 1) * episode_runtime * 1000  # Convert to milliseconds
        except Exception as e:
            print("Error:", str(e))
            return None

    def checkService(self, tvshow):
        try:
            # Fetch episode data from the local database or other data source
            # In this example, we will use a dummy data
            # Replace this with your logic to fetch episode data
            episode_data = {
                "season_number": 1,
                "episode_number": 2,
                "runtime": 1800
            }
            return True, episode_data

        except Exception as e:
            print("Error:", str(e))
            return False, None

    def loadSkipData(self):
        skipFile = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'skipintro.json')
        if os.path.exists(skipFile):
            with open(skipFile, 'r') as f:
                return json.load(f)
        return {}

    def saveSkipData(self):
        skipFile = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), 'skipintro.json')
        with open(skipFile, 'w') as f:
            json.dump(self.skipData, f)

    def addDefaultSkip(self, tvshow):
        self.skipData[tvshow] = {
            "seconds": 30,
            "start": 10,
            "type": "prompt"
        }

    def onAddonInstall(self):
        self.create_skip_file()
        self.saveSkipData()

    def create_skip_file(self):
        series_list = self.get_tvshows()
        for tvshow in series_list:
            if tvshow not in self.skipData:
                self.addDefaultSkip(tvshow)

    def get_tvshows(self):
        db_file = xbmcvfs.translatePath("special://database/MyVideos119.db")
        connection = sqlite3.connect(db_file)
        cursor = connection.cursor()
        query = "SELECT c00 FROM tvshow"
        cursor.execute(query)
        tvshows = cursor.fetchall()
        cursor.close()
        connection.close()
        tvshow_list = [tvshow[0] for tvshow in tvshows]
        return tvshow_list
